import java.io.*;


public class DS {

    /*
     * Complete the twoStacks function below.
     */
   



    public static void main(String[] args) throws IOException {
         BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
       int x=Integer.parseInt(br.readLine());
         
if (x==1)
            System.out.println(-1);
else
            System.out.println(x+" "+x);

        }

        
    }