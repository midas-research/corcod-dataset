
import java.util.Scanner;

public class Main {
    static Scanner scan = new Scanner(System.in);

    public static void main(String [] args){
        int num = scan.nextInt();
        for(int i=0;i<num;i++){
            int a = scan.nextInt();
            int b = scan.nextInt();
            System.out.println(a+" "+2*a);
        }
    }
}
	  	    	    		 	  				 		 			