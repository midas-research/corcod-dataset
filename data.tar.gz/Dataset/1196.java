

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			int n = sc.nextInt();
			if (n % 2 != 0) {
				System.out.println("Ehab");
			} else {
				System.out.println("Mahmoud");
			}

		}

	}

}

					  	 	     	      		 			